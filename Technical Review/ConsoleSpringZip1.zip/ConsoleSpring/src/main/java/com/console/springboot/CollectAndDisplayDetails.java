package com.console.springboot;

import com.console.springboot.Validation;
import com.jdbc.springcomponent.Repository.EmployeeRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;

import java.sql.SQLException;
import java.util.*;



@ComponentScan("com.jdbc.springcomponent.services.EmployeeService")
public class CollectAndDisplayDetails {

    @Autowired
    EmployeeRepo employeeRepo;

    private static Logger logger = LoggerFactory.getLogger(EmployeeMenu.class);
    ResourceBundle resourceBundle = ResourceBundle.getBundle("application");
//    Activity employeeImplement = new DatabaseService();

    Scanner scanner = new Scanner(System.in);
    AddressDetails permanentAddress = new AddressDetails();
    AddressDetails temporaryAddress = new AddressDetails();




    public void addEmployeeDetails() {
        String yesNo;
        do {
            try {
                System.out.println("Employee Id: ");
                String empId = null;
                    int attempts = 0;


                while (attempts < 3) {
                    try {
                        empId = scanner.next();
                        if (!Validation.isValidId(empId)) {
                            if (employeeRepo.apiDoesEmployeeExists(empId)) {
                                throw new EmployeeException(resourceBundle.getString("emp.exists"));
                            }
                        }
                        break; // Break out of the loop if everything is ok
                    } catch (InputMismatchException e) {
                        attempts++;
                        logger.info("Not valid format");
                        scanner.nextLine(); // Clear the input buffer
                    } catch (EmployeeException e) {
                        logger.info(e.getMessage());
                        System.out.println(e.getMessage());
                        System.out.println();
                        return;
                    }
                    if (attempts == 3) {
                        logger.info("limit exceeded for re-entering the employee id");
                        System.out.println("Try again later.");
                        return;
                    }
                    System.out.println("Enter valid employee id");
                }
                scanner.nextLine();
                System.out.println(resourceBundle.getString("First.name"));
                String name = scanner.nextLine();

                System.out.println(resourceBundle.getString("Middle.name"));
                String middleName = scanner.nextLine();
                System.out.println(resourceBundle.getString("Last.name"));
                String lastName = scanner.nextLine();

                System.out.println(resourceBundle.getString("Email"));
                int count = 0;
                String email;
                while (true) {
                    try {
                        email = scanner.next();
                        if (!Validation.isValidEmail(email)) {
                            if (count == 3) {
                                logger.info("limit exceeded for re-entering the email");
                                System.out.println("Try again later.");
                                return;
                            }
                            logger.warn("Invalid Email.\n Please re-enter the valid email id.\n");
                            throw new EmployeeException(resourceBundle.getString("invalid.email"));
                        } else
                            break;
                    } catch (EmployeeException e) {
                        logger.info(e.getMessage());
                        System.out.println(e.getMessage());

                    }
                    count++;
                }


                String phNo = null;
                System.out.println("Phone Number");
                count = 0;
                while (true) {
                    try {
                        phNo = scanner.next();
                        if (!Validation.isValidPhone(phNo)) {
                            if (count == 4) {
                                logger.info("limit exceeded for re-entering the phone number");
                                System.out.println("Try again later.");
                                scanner.nextLine();
                                return;
                            }
                            logger.warn("Invalid phone number.\n Please re-enter the valid Phone number.\n");
                            throw new EmployeeException(resourceBundle.getString("invalid.phone"));
                        } else {
                            break;
                        }
                    } catch (EmployeeException e) {
                        System.out.println(e.getMessage());
                    }
                    count++;

                }


                System.out.println("Enter the details of Temporary Address");
                System.out.println("House/Flat Number:");
                String houseNo = scanner.next();
                temporaryAddress.setHouseNumber(houseNo);
                scanner.nextLine();
                System.out.println("Street Address:");
                Scanner scanner1 = new Scanner(System.in);
                String streetAddress = scanner.nextLine();
                temporaryAddress.setStreetAddress(streetAddress);
                System.out.println("City: ");
                String city = scanner.nextLine();
                temporaryAddress.setCityName(city);
//                scanner.nextLine();
                System.out.println("State: ");
                String state = scanner.next();
                temporaryAddress.setState(state);
                scanner.nextLine();
                System.out.println("PIN: ");

                String pin;
                count = 0;
                while (true) {
                    try {
                        pin = scanner.nextLine();
                        if (!Validation.isValidPin(pin)) {
                            if (count == 3) {
                                System.out.println("Try again later.");
                                logger.info("attempts limit exceeded");

                                scanner.nextLine();
                                return;
                            }
//                            System.out.println("Invalid PIN.\n Please re-enter the valid PIN.\n");
                            logger.warn("Invalid PIN.\n");
                            throw new EmployeeException(resourceBundle.getString("invalid.pin"));
                        } else
                            break;

                    } catch (EmployeeException e) {
                        System.out.println(e.getMessage());
                    }
                    count++;
                }     //while (!PinCodeValidation.isValidPin(pin));
                temporaryAddress.setAddressPin(pin);
                System.out.println("Enter the the details of Permanent Address");
                System.out.println("House Number:");
                String pHouseNo = scanner.next();
                permanentAddress.setHouseNumber(pHouseNo);
                scanner.nextLine();
                System.out.println("Street: ");
                String pStreet = scanner.nextLine();
                permanentAddress.setStreetAddress(pStreet);
                System.out.println("City: ");
                String pCity = scanner.nextLine();
                permanentAddress.setCityName(pCity);
                System.out.println("State: ");
                String pState = scanner.next();
                permanentAddress.setState(pState);
                scanner.nextLine();
                System.out.println("PIN: ");
                String pPin;
                count = 0;
                while (true) {
                    try {
                        pPin = scanner.nextLine();
                        if (!Validation.isValidPin(pPin)) {
                            if (count == 3) {
                                logger.info("limit exceeded for re-entering the pin");
                                System.out.println("Try again later.");

                                scanner.nextLine();
                                return;
                            }
                            logger.warn(resourceBundle.getString("invalid.pin"));
                            System.out.println(resourceBundle.getString("invalid.pin"));
                            throw new EmployeeException(resourceBundle.getString("invalid.pin"));
                        } else
                            break;

                    } catch (EmployeeException e) {
                        System.out.println(e.getMessage());
                    }
                    count++;
                }
                permanentAddress.setAddressPin(pPin);


                Employee employee = new Employee(name, middleName, lastName, email, phNo, empId);
                com.jdbc.springcomponent.entity.Employee employeeBackend = new com.jdbc.springcomponent.entity.Employee();
                employeeBackend.setEmployeeFirstName(employee.getEmployeeFirstName());
                employeeBackend.setEmployeeMiddleName(employee.getEmployeeMiddleName());
                employeeBackend.setEmployeeLastName(employee.getEmployeeLastName());
                employeeBackend.setEmployeeEmail(employee.getEmployeeEmail());
                employeeBackend.setEmployeeMobileNumber(employee.getEmployeeMobileNumber());
                employeeBackend.setEmployeeId(employee.getEmployeeId());

                com.jdbc.springcomponent.entity.AddressDetails permanentAddressBackend = new com.jdbc.springcomponent.entity.AddressDetails();
                permanentAddressBackend.setHouseNumber(permanentAddress.getHouseNumber());
                permanentAddressBackend.setCityName(permanentAddress.getCityName());
                permanentAddressBackend.setStreetAddress(permanentAddress.getStreetAddress());
                permanentAddressBackend.setState(permanentAddress.getState());
                permanentAddressBackend.setAddressPin(permanentAddress.getAddressPin());


                com.jdbc.springcomponent.entity.AddressDetails temporaryAddressBackend = new com.jdbc.springcomponent.entity.AddressDetails();
                temporaryAddressBackend.setHouseNumber(temporaryAddress.getHouseNumber());
                temporaryAddressBackend.setCityName(temporaryAddress.getCityName());
                temporaryAddressBackend.setStreetAddress(temporaryAddress.getStreetAddress());
                temporaryAddressBackend.setState(temporaryAddress.getState());
                temporaryAddressBackend.setAddressPin(temporaryAddress.getAddressPin());
                employeeBackend.setPermanentAddress(permanentAddressBackend);
                employeeBackend.setTemporaryAddress(temporaryAddressBackend);

               com.jdbc.springcomponent.entity.Employee employee1 = employeeRepo.apiSave(employeeBackend);

//                try {
//                    if(employee.saveAll(employee) != null) System.out.println("Employee Details added successfully!");
//                    else System.out.println("Failed to add employee details!");
//                }catch(EmployeeExceptions employeeExceptions){
//                    System.out.println(employeeExceptions.getMessage());
//                }
//                boolean isPermanentAddressAdded =employeeImplement.addPermanentAddressDetails(permanentAddressBackend);
//                boolean isTemporaryAddressAdded =employeeImplement.addTemporaryAddressDetails(temporaryAddressBackend);
//                if (isEmployeeAdded) {
//                    System.out.println("Employee details added successfully.");
//                } else {
//                    System.out.println("Failed to add employee details.");
//                }
                System.out.println("Do you want to read one more employee Details(yes/no)");
                yesNo = scanner.next();
                scanner.nextLine();

            } catch (InputMismatchException error) {
                logger.error("Input Mismatch occurred while entering " + error.getMessage());
                yesNo = "no";
            }

        } while (yesNo.equalsIgnoreCase("yes"));

    }


    public void displayDetails() {
        try {
            List<com.jdbc.springcomponent.entity.Employee> frontendDetails = employeeRepo.apiGetEmployees();
            List<Employee> employeeDetails = convertToEmployeeFrontend(frontendDetails);

            if (!employeeDetails.isEmpty()) {
                System.out.println("Employee Details:");
                for (Employee employee : employeeDetails) {
                    System.out.println(resourceBundle.getString("First.name") + employee.getEmployeeFirstName());
                    System.out.println(resourceBundle.getString("Middle.name") + employee.getEmployeeMiddleName());
                    System.out.println(resourceBundle.getString("Last.name") + employee.getEmployeeLastName());
                    System.out.println(resourceBundle.getString("Employee.ID") + employee.getEmployeeId());
                    System.out.println(resourceBundle.getString("Email") + employee.getEmployeeEmail());
                    System.out.println(resourceBundle.getString("phone.number") + employee.getEmployeeMobileNumber());
                    System.out.println();
                    System.out.println(resourceBundle.getString("print.temporary.address"));
                    displayAddressDetails(employee.getTemporaryAddress());
                    System.out.println();
                    System.out.println(resourceBundle.getString("print.permanent.address"));
                    displayAddressDetails(employee.getPermanentAddress());
                    System.out.println();
                    System.out.println("--------------------------------------------------------------------------------------------------------------");
                }
            } else
                System.out.println("No employees found");
        }catch(Exception error)
        {
//                System.out.println(error.printStackTrace());
            System.out.println("error in displaying");
        }
    }


    //        display address details
    private void displayAddressDetails(AddressDetails address) {
        System.out.println(resourceBundle.getString("address.house")+address.getHouseNumber());
        System.out.println(resourceBundle.getString("address.street")+address.getStreetAddress());
        System.out.println(resourceBundle.getString("address.city")+address.getCityName());
        System.out.println(resourceBundle.getString("address.state")+address.getState());
        System.out.println(resourceBundle.getString("address.pin")+address.getAddressPin());
        System.out.println();
    }


    // conversion from backend entity to frontend
    private List<com.console.springboot.Employee> convertToEmployeeFrontend(List<com.jdbc.springcomponent.entity.Employee> employee) {
        List<com.console.springboot.Employee> frontendList = new ArrayList<>();
        for (com.jdbc.springcomponent.entity.Employee employees:employee) {
            com.console.springboot.Employee frontend = new com.console.springboot.Employee();
            AddressDetails permanentAddressFrontend = convertToAddressDetailsFrontend(employees.getPermanentAddress());
            AddressDetails temporaryAddressFrontend = convertToAddressDetailsFrontend(employees.getTemporaryAddress());

            frontend.setEmployeeFirstName(employees.getEmployeeFirstName());
            frontend.setEmployeeMiddleName(employees.getEmployeeMiddleName());
            frontend.setEmployeeLastName(employees.getEmployeeLastName());
            frontend.setEmployeeEmail(employees.getEmployeeEmail());
            frontend.setEmployeeMobileNumber(employees.getEmployeeMobileNumber());
            frontend.setEmployeeId(employees.getEmployeeId());
            frontend.setPermanentAddress(permanentAddressFrontend);
            frontend.setTemporaryAddress(temporaryAddressFrontend);

            frontendList.add(frontend);
        }
        return frontendList;
    }

    private AddressDetails convertToAddressDetailsFrontend(com.jdbc.springcomponent.entity.AddressDetails address) {
        AddressDetails addressFrontend = new AddressDetails();
        addressFrontend.setHouseNumber(address.getHouseNumber());
        addressFrontend.setStreetAddress(address.getStreetAddress());
        addressFrontend.setCityName(address.getCityName());
        addressFrontend.setState(address.getState());
        addressFrontend.setAddressPin(address.getAddressPin());
        return addressFrontend;
    }







    // retrieving employee details based on the given employee id
    public void searchById()  {
        System.out.println("Enter the employeeId");
        String id;
//        scanner.nextInt();
        int count=0;
        while(true) {
            try {
                id = scanner.next();
                if (!Validation.isValidPin(id)) {
                    if(count==3){
                        System.out.println("Try again later.");
                        logger.info("attempts limit exceeded");

                        scanner.nextLine();
                        return;
                    }
//                            System.out.println("Invalid PIN.\n Please re-enter the valid PIN.\n");
                    logger.warn("Invalid Employee Id.\n");
                    throw new EmployeeException(resourceBundle.getString("invalid.id"));
                } else
                    break;

            }
            catch (EmployeeException e){
                System.out.println(e.getMessage());
            }
            count++;
        }
        scanner.nextLine();
        try {


            com.jdbc.springcomponent.entity.Employee employeeBackend = employeeRepo.apiGetEmployeeById(id);
            if (employeeBackend != null) {
                Employee employee = convertToEmployeeFrontendObject(employeeBackend);
                System.out.println(resourceBundle.getString("First.name") + employee.getEmployeeFirstName());
                System.out.println(resourceBundle.getString("Middle.name") + employee.getEmployeeMiddleName());
                System.out.println(resourceBundle.getString("Last.name") + employee.getEmployeeLastName());
                System.out.println(resourceBundle.getString("Employee.ID") + employee.getEmployeeId());
                System.out.println(resourceBundle.getString("Email") + employee.getEmployeeEmail());
                System.out.println(resourceBundle.getString("phone.number") + employee.getEmployeeMobileNumber());
                System.out.println();
                System.out.println(resourceBundle.getString("print.temporary.address"));
                displayAddressDetails(employee.getTemporaryAddress());
                System.out.println();
                System.out.println(resourceBundle.getString("print.permanent.address"));
                displayAddressDetails(employee.getPermanentAddress());
                System.out.println("-------------------------------------------------------------------------------------------------------");
                System.out.println();
            } else
                throw new EmployeeException(resourceBundle.getString("employee.doesNotExists"));
//                System.out.println("Employee does not exists");
        }catch (EmployeeException e){
            System.out.println(e.getMessage());
        }
    }

    private int readEmployeeId(Scanner scanner) throws EmployeeException {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            throw new EmployeeException("Invalid input format. Please enter a valid employee ID (an integer).");
        }
    }
    private Employee convertToEmployeeFrontendObject(com.jdbc.springcomponent.entity.Employee employee) {
//        Employee frontend = new Employee();
        com.console.springboot.Employee frontend = new com.console.springboot.Employee();

        // Set personal details
        frontend.setEmployeeFirstName(employee.getEmployeeFirstName());
        frontend.setEmployeeMiddleName(employee.getEmployeeMiddleName());
        frontend.setEmployeeLastName(employee.getEmployeeLastName());
        frontend.setEmployeeEmail(employee.getEmployeeEmail());
        frontend.setEmployeeMobileNumber(employee.getEmployeeMobileNumber());
        frontend.setEmployeeId(employee.getEmployeeId());

        // Set address details
        com.console.springboot.AddressDetails temporaryAddress = convertToAddressDetails(employee.getTemporaryAddress());
        AddressDetails permanentAddress = convertToAddressDetails(employee.getPermanentAddress());
        frontend.setTemporaryAddress(new AddressDetails(
                temporaryAddress.getCityName(),
                temporaryAddress.getState(),
                temporaryAddress.getAddressPin(),
                temporaryAddress.getHouseNumber(),
                temporaryAddress.getStreetAddress()

        ));
        frontend.setPermanentAddress(new AddressDetails(
                permanentAddress.getCityName(),
                permanentAddress.getState(),
                permanentAddress.getAddressPin(),
                permanentAddress.getHouseNumber(),
                permanentAddress.getStreetAddress()

        ));

        return frontend;
    }

    private AddressDetails convertToAddressDetails(com.jdbc.springcomponent.entity.AddressDetails address) {
        AddressDetails addressFrontend = new AddressDetails();
        addressFrontend.setHouseNumber(address.getHouseNumber());
        addressFrontend.setStreetAddress(address.getStreetAddress());
        addressFrontend.setCityName(address.getCityName());
        addressFrontend.setState(address.getState());
        addressFrontend.setAddressPin(address.getAddressPin());
        return addressFrontend;
    }

    public void closeAll(){
        employeeRepo.closeResources();
    }
    public void searchByPinCode() {
        System.out.println(resourceBundle.getString("enter.pincode"));
        String pinCode ;
        int count=0;
        while(true) {
            try {
                pinCode = scanner.nextLine();
                if (!Validation.isValidPin(pinCode)) {
                    if(count==3){
                        System.out.println("Try again later.");
                        logger.info("attempts limit exceeded");

                        scanner.nextLine();
                        return;
                    }
//                            System.out.println("Invalid PIN.\n Please re-enter the valid PIN.\n");
                    logger.warn("Invalid PIN.\n");
                    throw new EmployeeException(resourceBundle.getString("invalid.pin"));
                } else
                    break;

            }
            catch (EmployeeException e){
                System.out.println(e.getMessage());
            }
            count++;
        }
        try {
            List<com.jdbc.springcomponent.entity.Employee> frontendDetails = employeeRepo.apiEmployeeByPinCode(pinCode);
            List<com.console.springboot.Employee> employeeDetails = convertToEmployeeFrontend(frontendDetails);
            if (!employeeDetails.isEmpty()) {
                System.out.println("Details of Employee with  PIN code " + pinCode);
                for (Employee employee : employeeDetails) {
                    System.out.println(resourceBundle.getString("First.name") + employee.getEmployeeFirstName());
                    System.out.println(resourceBundle.getString("Middle.name") + employee.getEmployeeMiddleName());
                    System.out.println(resourceBundle.getString("Last.name") + employee.getEmployeeLastName());
                    System.out.println(resourceBundle.getString("Employee.ID") + employee.getEmployeeId());
                    System.out.println(resourceBundle.getString("Email"));
                    System.out.println(resourceBundle.getString("phone.number") + employee.getEmployeeMobileNumber());
                    System.out.println();
                    System.out.println(resourceBundle.getString("print.temporary.address"));
                    displayAddressDetails(employee.getTemporaryAddress());
                    System.out.println();
                    System.out.println(resourceBundle.getString("print.permanent.address"));
                    displayAddressDetails(employee.getPermanentAddress());
                    System.out.println();
                    System.out.println("--------------------------------------------------------------------------------------------------------------");

                }
            } else
//                System.out.println("Employee with pin code is not found");
                throw new EmployeeException("Employee with PIN code: "+pinCode+" does not exists ");
        }

        catch (EmployeeException e){
            System.out.println(e.getMessage());
        }

    }

}
