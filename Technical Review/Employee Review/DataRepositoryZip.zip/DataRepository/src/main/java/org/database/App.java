package org.database;

import org.exceptions.ConnectionException;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws ConnectionException {
        DatabaseService databaseService=new DatabaseService();
        System.out.println( "Hello World!" );
//        System.out.println(databaseService.getEmployees().toString());
//        System.out.println(databaseService.employeeByPinCode("574274"));
        System.out.println(databaseService.getEmployees());
    }
}
