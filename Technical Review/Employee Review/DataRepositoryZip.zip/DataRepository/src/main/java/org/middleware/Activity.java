package org.middleware;

import org.entity.AddressDetails;
import org.entity.Employee;
import org.exceptions.EmployeeException;

import java.util.List;

public interface Activity  {

//    void addEmployees(List<EmployeeDetails> empList);// change the return type so that user can get the confirmation of data addede to file successfully

    boolean addEmployeePersonalDetails(Employee employee) throws EmployeeException;
    boolean addPermanentAddressDetails(AddressDetails addressDetails) throws EmployeeException;
    boolean addTemporaryAddressDetails(AddressDetails addressDetails) throws EmployeeException;
    boolean doesEmployeeExists(String id);
    Employee getEmployeeById(String employeeId);
    List<Employee> employeeByPinCode(String pinCode);
    List<Employee> getEmployees();
    void closeResources();
}
