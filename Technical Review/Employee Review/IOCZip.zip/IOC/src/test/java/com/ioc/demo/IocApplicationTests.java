package com.ioc.demo;

//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;

//import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class IocApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
